require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data');
const productsFile = path.join(DATA, 'products.json');
const statsFile = path.join(DATA, 'stats.json');
const ordersFile = path.join(DATA, 'orders.json');
const usersFile = path.join(DATA, 'users.json');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function read(file, fallback){ try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch { return fallback; } }
function write(file, data){ fs.writeFileSync(file, JSON.stringify(data,null,2)); }
function slug(s){ return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'') || String(Date.now()); }
function publicConfig(){ return { storeName: process.env.STORE_NAME || 'HardStore', supportUrl: process.env.DISCORD_SUPPORT_URL || '#', pix: process.env.PIX_CHAVE || 'Configure sua chave Pix no .env' }; }

function makeCode(){ return String(Math.floor(100000 + Math.random()*900000)); }
function safeUser(u){ return { id:u.id, name:u.name, email:u.email, avatar:u.avatar || '', provider:u.provider || 'email', verified:!!u.verified, discord:u.discord || '' }; }
function findUserByEmail(email){ return read(usersFile,[]).find(u=>String(u.email).toLowerCase()===String(email).toLowerCase()); }
async function sendVerifyEmail(email, code){
 const user = process.env.GMAIL_USER || process.env.EMAIL_USER;
 const pass = process.env.GMAIL_APP_PASSWORD || process.env.EMAIL_PASS;
 if(!user || !pass || user.includes('seuemail') || pass.includes('sua_senha')) {
   console.log('Email não enviado: configure GMAIL_USER e GMAIL_APP_PASSWORD no .env');
   return false;
 }
 const transporter = nodemailer.createTransport({ service:'gmail', auth:{ user, pass } });
 await transporter.sendMail({
   from: `"HardStore" <${user}>`,
   to: email,
   subject: 'Código de verificação HardStore',
   text: `Seu código de verificação HardStore é: ${code}`,
   html: `<div style="font-family:Arial;background:#061122;color:white;padding:24px;border-radius:12px"><h2>HardStore</h2><p>Seu código de verificação é:</p><h1 style="letter-spacing:4px;color:#27a8ff">${code}</h1><p>Use este código no site para confirmar seu e-mail.</p></div>`
 });
 return true;
}


app.get('/api/config', (req,res)=>res.json(publicConfig()));

app.post('/api/auth/email/start', async (req,res)=>{
 const {email, name, discord} = req.body || {};
 if(!email || !String(email).includes('@')) return res.status(400).json({error:'Coloque um e-mail válido.'});
 const users=read(usersFile,[]);
 let u=users.find(x=>String(x.email).toLowerCase()===String(email).toLowerCase());
 const code=makeCode();
 if(!u){
   u={id:'U-'+Date.now(), name:name||String(email).split('@')[0], email, discord:discord||'', provider:'email', verified:false, verifyCode:code, avatar:''};
   users.push(u);
 } else {
   u.name=name||u.name; u.discord=discord||u.discord; u.verifyCode=code;
 }
 write(usersFile,users);
 try { await sendVerifyEmail(email, code); } catch(e){ console.log('Erro enviando email:', e.message); }
 res.json({ok:true, message:'Código enviado. Verifique seu e-mail.'});
});
app.post('/api/auth/email/verify', (req,res)=>{
 const {email, code} = req.body || {};
 const users=read(usersFile,[]);
 const u=users.find(x=>String(x.email).toLowerCase()===String(email).toLowerCase());
 if(!u) return res.status(404).json({error:'Conta não encontrada.'});
 if(String(u.verifyCode)!==String(code)) return res.status(400).json({error:'Código incorreto.'});
 u.verified=true; delete u.verifyCode; write(usersFile,users); res.json({ok:true, user:safeUser(u)});
});
app.get('/auth/discord', (req,res)=>{
 const id=process.env.DISCORD_OAUTH_CLIENT_ID || process.env.DISCORD_CLIENT_ID;
 const redirect=encodeURIComponent((process.env.SITE_URL||`http://localhost:${PORT}`)+'/auth/discord/callback');
 if(!id) return res.send('Configure DISCORD_OAUTH_CLIENT_ID no .env');
 res.redirect(`https://discord.com/oauth2/authorize?client_id=${id}&response_type=code&redirect_uri=${redirect}&scope=identify%20email`);
});
app.get('/auth/discord/callback', async (req,res)=>{
 try{
  const code=req.query.code;
  const client_id=process.env.DISCORD_OAUTH_CLIENT_ID || process.env.DISCORD_CLIENT_ID;
  const client_secret=process.env.DISCORD_OAUTH_CLIENT_SECRET || process.env.DISCORD_CLIENT_SECRET;
  const redirect_uri=(process.env.SITE_URL||`http://localhost:${PORT}`)+'/auth/discord/callback';
  if(!code || !client_id || !client_secret) throw new Error('OAuth Discord não configurado.');
  const tokenResp=await fetch('https://discord.com/api/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id,client_secret,grant_type:'authorization_code',code,redirect_uri})});
  const token=await tokenResp.json();
  const userResp=await fetch('https://discord.com/api/users/@me',{headers:{Authorization:`Bearer ${token.access_token}`}});
  const du=await userResp.json();
  const email=du.email || `${du.id}@discord.local`;
  const users=read(usersFile,[]);
  let u=users.find(x=>x.providerId===du.id || String(x.email).toLowerCase()===String(email).toLowerCase());
  const avatar=du.avatar?`https://cdn.discordapp.com/avatars/${du.id}/${du.avatar}.png`:'';
  if(!u){u={id:'U-'+Date.now(), provider:'discord', providerId:du.id, name:du.global_name||du.username, email, avatar, verified:true, discord:du.username}; users.push(u);}
  else {u.name=du.global_name||du.username; u.email=email; u.avatar=avatar; u.provider='discord'; u.providerId=du.id; u.verified=true;}
  write(usersFile,users);
  res.redirect('/auth-success.html#user='+encodeURIComponent(JSON.stringify(safeUser(u))));
 }catch(e){ res.send('Erro no login Discord: '+e.message); }
});
app.get('/auth/google', (req,res)=>{
 const id=process.env.GOOGLE_CLIENT_ID;
 const redirect=encodeURIComponent((process.env.SITE_URL||`http://localhost:${PORT}`)+'/auth/google/callback');
 if(!id) return res.send('Configure GOOGLE_CLIENT_ID no .env');
 res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?client_id=${id}&redirect_uri=${redirect}&response_type=code&scope=openid%20email%20profile`);
});
app.get('/auth/google/callback', async (req,res)=>{
 try{
  const code=req.query.code;
  const client_id=process.env.GOOGLE_CLIENT_ID, client_secret=process.env.GOOGLE_CLIENT_SECRET;
  const redirect_uri=(process.env.SITE_URL||`http://localhost:${PORT}`)+'/auth/google/callback';
  if(!code || !client_id || !client_secret) throw new Error('OAuth Google não configurado.');
  const tokenResp=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id,client_secret,code,grant_type:'authorization_code',redirect_uri})});
  const token=await tokenResp.json();
  const infoResp=await fetch('https://www.googleapis.com/oauth2/v2/userinfo',{headers:{Authorization:`Bearer ${token.access_token}`}});
  const gu=await infoResp.json();
  const users=read(usersFile,[]);
  let u=users.find(x=>x.providerId===gu.id || String(x.email).toLowerCase()===String(gu.email).toLowerCase());
  if(!u){u={id:'U-'+Date.now(), provider:'google', providerId:gu.id, name:gu.name, email:gu.email, avatar:gu.picture||'', verified:true}; users.push(u);}
  else {u.name=gu.name; u.email=gu.email; u.avatar=gu.picture||''; u.provider='google'; u.providerId=gu.id; u.verified=true;}
  write(usersFile,users);
  res.redirect('/auth-success.html#user='+encodeURIComponent(JSON.stringify(safeUser(u))));
 }catch(e){ res.send('Erro no login Google: '+e.message); }
});

app.get('/api/products', (req,res)=>res.json(read(productsFile, [])));
app.get('/api/products/:id', (req,res)=>{ const p=read(productsFile,[]).find(x=>x.id===req.params.id); if(!p) return res.status(404).json({error:'Produto não encontrado'}); res.json(p); });
app.get('/api/stats', (req,res)=>res.json(read(statsFile,{sales:0,accesses:0,rating:0,reviews:0,feedbacks:[]})));
app.post('/api/access', (req,res)=>{ const s=read(statsFile,{sales:0,accesses:0,rating:0,reviews:0,feedbacks:[]}); s.accesses=(s.accesses||0)+1; write(statsFile,s); res.json(s); });
app.post('/api/orders', (req,res)=>{ const orders=read(ordersFile,[]); const products=read(productsFile,[]); const product=products.find(p=>p.id===req.body.productId); if(!product) return res.status(400).json({error:'Produto inválido'}); const order={ id:'HS-'+Date.now(), productId:product.id, productName:product.name, price:product.price, email:req.body.email||'', discord:req.body.discord||'', status:'aguardando', createdAt:new Date().toISOString() }; orders.push(order); write(ordersFile,orders); res.json(order); });
app.get('/api/orders/:email', (req,res)=>{ const orders=read(ordersFile,[]).filter(o=>o.email===req.params.email); res.json(orders); });

app.get('/', (req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.get('/produto/:id', (req,res)=>res.sendFile(path.join(__dirname,'public','product.html')));
app.get('/checkout/:id', (req,res)=>res.sendFile(path.join(__dirname,'public','checkout.html')));

async function startBot(){
 const token=process.env.DISCORD_BOT_TOKEN;
 if(!token || token.includes('COLOQUE')) { console.log('Bot Discord não ligado: configure DISCORD_BOT_TOKEN no .env'); return; }
 const client=new Client({ intents:[GatewayIntentBits.Guilds] });
 const commands=[
  new SlashCommandBuilder().setName('produto_criar').setDescription('Criar produto no site').addStringOption(o=>o.setName('nome').setDescription('Nome').setRequired(true)).addNumberOption(o=>o.setName('preco').setDescription('Preço').setRequired(true)).addIntegerOption(o=>o.setName('stock').setDescription('Estoque').setRequired(true)).addStringOption(o=>o.setName('imagem').setDescription('URL da imagem').setRequired(true)).addStringOption(o=>o.setName('descricao').setDescription('Descrição').setRequired(false)).addStringOption(o=>o.setName('emoji').setDescription('Emoji').setRequired(false)),
  new SlashCommandBuilder().setName('produto_editar').setDescription('Editar produto').addStringOption(o=>o.setName('id').setDescription('ID').setRequired(true)).addStringOption(o=>o.setName('nome').setDescription('Novo nome')).addNumberOption(o=>o.setName('preco').setDescription('Preço')).addIntegerOption(o=>o.setName('stock').setDescription('Estoque')).addStringOption(o=>o.setName('imagem').setDescription('URL imagem')).addStringOption(o=>o.setName('descricao').setDescription('Descrição')).addStringOption(o=>o.setName('emoji').setDescription('Emoji')),
  new SlashCommandBuilder().setName('produto_remover').setDescription('Remover produto').addStringOption(o=>o.setName('id').setDescription('ID').setRequired(true)),
  new SlashCommandBuilder().setName('produtos').setDescription('Listar produtos'),
  new SlashCommandBuilder().setName('pedido_aprovar').setDescription('Aprovar pedido e atualizar vendas/estoque').addStringOption(o=>o.setName('id').setDescription('ID do pedido').setRequired(true)),
  new SlashCommandBuilder().setName('feedback').setDescription('Adicionar avaliação ao site').addIntegerOption(o=>o.setName('estrelas').setDescription('1 a 5').setRequired(true)).addStringOption(o=>o.setName('comentario').setDescription('Comentário').setRequired(true)),
  new SlashCommandBuilder().setName('stats_set').setDescription('Alterar números do início').addIntegerOption(o=>o.setName('vendas').setDescription('Vendas realizadas')).addIntegerOption(o=>o.setName('acessos').setDescription('Acessos')).addNumberOption(o=>o.setName('nota').setDescription('Nota'))
 ].map(c=>c.toJSON());
 const rest=new REST({version:'10'}).setToken(token);
 try { await rest.put(Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID), { body:commands }); console.log('Comandos do bot registrados.'); } catch(e){ console.log('Erro registrando comandos:', e.message); }
 client.on('interactionCreate', async i=>{
  if(!i.isChatInputCommand()) return;
  const adminRole=process.env.ADMIN_ROLE_ID;
  if(adminRole && !i.member.roles.cache.has(adminRole)) return i.reply({content:'Sem permissão.', ephemeral:true});
  let products=read(productsFile,[]), stats=read(statsFile,{sales:0,accesses:0,rating:0,reviews:0,feedbacks:[]}), orders=read(ordersFile,[]);
  if(i.commandName==='produto_criar'){
   const name=i.options.getString('nome'), id=slug(name); const p={id,name,price:i.options.getNumber('preco'),oldPrice:null,stock:i.options.getInteger('stock'),image:i.options.getString('imagem'),description:i.options.getString('descricao')||'Produto digital com entrega pelo suporte.',emoji:i.options.getString('emoji')||'💎',discount:'',gallery:[],requirements:''};
   products.push(p); write(productsFile,products); return i.reply(`✅ Produto criado: ${name}\nID: \`${id}\``);
  }
  if(i.commandName==='produto_editar'){
   const id=i.options.getString('id'); const p=products.find(x=>x.id===id); if(!p) return i.reply({content:'Produto não encontrado.', ephemeral:true});
   ['nome','imagem','descricao','emoji'].forEach(k=>{ const v=i.options.getString(k); if(v) p[k==='nome'?'name':k]=v; });
   const price=i.options.getNumber('preco'); if(price!==null) p.price=price; const stock=i.options.getInteger('stock'); if(stock!==null) p.stock=stock;
   write(productsFile,products); return i.reply(`✅ Produto atualizado: ${p.name}`);
  }
  if(i.commandName==='produto_remover'){ const id=i.options.getString('id'); products=products.filter(p=>p.id!==id); write(productsFile,products); return i.reply(`🗑️ Produto removido: ${id}`); }
  if(i.commandName==='produtos') return i.reply(products.map(p=>`\`${p.id}\` - ${p.emoji||''} ${p.name} | R$ ${p.price} | Stock ${p.stock}`).join('\n')||'Nenhum produto.');
  if(i.commandName==='pedido_aprovar'){
   const id=i.options.getString('id'); const o=orders.find(x=>x.id===id); if(!o) return i.reply({content:'Pedido não encontrado.', ephemeral:true}); o.status='pago'; o.paidAt=new Date().toISOString();
   const p=products.find(x=>x.id===o.productId); if(p && p.stock>0) p.stock-=1; stats.sales=(stats.sales||0)+1; write(ordersFile,orders); write(productsFile,products); write(statsFile,stats); return i.reply(`✅ Pedido ${id} aprovado. Site atualizado.`);
  }
  if(i.commandName==='feedback'){
   const stars=Math.max(1,Math.min(5,i.options.getInteger('estrelas'))), comentario=i.options.getString('comentario'); stats.feedbacks=stats.feedbacks||[]; stats.feedbacks.unshift({user:i.user.username, avatar:i.user.displayAvatarURL(), stars, comentario, date:new Date().toISOString()}); stats.reviews=(stats.reviews||0)+1; const total=(stats.rating||5)*(stats.reviews-1)+stars; stats.rating=Number((total/stats.reviews).toFixed(1)); write(statsFile,stats); return i.reply('⭐ Avaliação adicionada e site atualizado.');
  }
  if(i.commandName==='stats_set'){
   const v=i.options.getInteger('vendas'), a=i.options.getInteger('acessos'), n=i.options.getNumber('nota'); if(v!==null) stats.sales=v; if(a!==null) stats.accesses=a; if(n!==null) stats.rating=n; write(statsFile,stats); return i.reply('✅ Estatísticas atualizadas.');
  }
 });
 client.once('ready',()=>console.log(`Bot ligado: ${client.user.tag}`));
 client.login(token).catch(e=>console.log('Erro ao ligar bot:', e.message));
}

app.listen(PORT, ()=>{ console.log(`Site online: http://localhost:${PORT}`); startBot(); });
